IMPORTANT: Upload index.html itself to the root of the GitHub repository. Do not upload only the ZIP file.
