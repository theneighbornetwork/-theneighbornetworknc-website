THE NEIGHBOR NETWORK — READY TO PUBLISH

FASTEST NETLIFY METHOD
1. Unzip this folder.
2. Go to Netlify.
3. Drag the folder named TheNeighborNetwork_Final into the Netlify upload area.
4. Netlify will publish it.

GITHUB METHOD
1. Open your GitHub repository.
2. Choose “uploading an existing file.”
3. Upload index.html.
4. Click “Commit changes.”
5. Connect that repository to Netlify.

Phone number used throughout: (980) 505-7903
Domain: theneighbornetworknc.com
